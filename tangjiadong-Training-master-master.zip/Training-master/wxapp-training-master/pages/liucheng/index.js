//流程
Page({
    data: {
        serviceList: [
            {
                icon:"../../image/icon1.png",
                title:"师资力量雄厚"
            },
            {
                icon:"../../image/icon2.png",
                title:"专业培训课程"
            },
            {
                icon:"../../image/icon3.png",
                title:"IT企业合作"
            },
            {
                icon:"../../image/icon4.png",
                title:"技术新颖"
            },
            {
                icon:"../../image/icon5.png",
                title:"密封式集训"
            },
            {
                icon:"../../image/icon6.png",
                title:"保障学员就业"
            }
        ],
        flowProcessList: ["咨询报名","交纳定金","确认汇款","来校报道"],
        arrow:'../../image/right.png'
    },
});