package com.system.po;

public class Advice {
    private Integer adviceid;
    private String advice;
    private String phone;

    public Integer getAdviceid() {
        return adviceid;
    }

    public void setAdviceid(Integer adviceid) {
        this.adviceid = adviceid;
    }

    public String getAdvice() {
        return advice;
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
