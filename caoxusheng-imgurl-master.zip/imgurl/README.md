# imgurl

#### 介绍
免费图床，搭建自己的私有图片存储，网站 https://www.imgurl.club

#### 软件架构
springboot2, jfinal Enjoy 



## License
[Apache License.](https://www.apache.org/licenses/LICENSE-2.0)