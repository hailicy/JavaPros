### 基于微信小程序的培训机构管理系统

**该项目博客介绍以及环境搭建：https://blog.csdn.net/qq_38285537/article/details/91056177**